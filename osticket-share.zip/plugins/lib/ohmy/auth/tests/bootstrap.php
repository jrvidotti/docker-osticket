/*
 * Copyright (c) 2014, Yahoo! Inc. All rights reserved.
 * Copyrights licensed under the New BSD License.
 * See the accompanying LICENSE file for terms.
 */
<?php
/**
 * Fire up the autoloader
 */
require_once __DIR__ . '/../vendor/autoload.php';
